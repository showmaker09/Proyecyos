﻿using System;

namespace CalculadoraCalificaciones
{
    class Estudiante
    {
        public double Practicas { get; set; }
        public double Examen { get; set; }
        public double Tareas { get; set; }

        public double CalcularCalificacionFinal()
        {
            double porcentajePracticas = 0.55;
            double porcentajeExamen = 0.30;
            double porcentajeTareas = 0.15;

            return (Practicas * porcentajePracticas) + 
                   (Examen * porcentajeExamen) +
                   (Tareas * porcentajeTareas);
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            // Crear un objeto Estudiante
            Estudiante estudiante = new Estudiante();

            // Solicitar al usuario las calificaciones
            Console.Write("Ingrese la calificación de las prácticas (0-100): ");
            estudiante.Practicas = Convert.ToDouble(Console.ReadLine());

            Console.Write("Ingrese la calificación del examen (0-100): ");
            estudiante.Examen = Convert.ToDouble(Console.ReadLine());

            Console.Write("Ingrese la calificación de las tareas (0-100): ");
            estudiante.Tareas = Convert.ToDouble(Console.ReadLine());

            // Calcular y mostrar la calificación final
            double calificacionFinal = estudiante.CalcularCalificacionFinal();
            Console.WriteLine("La calificación final del estudiante es: " + calificacionFinal);
        }
    }
}