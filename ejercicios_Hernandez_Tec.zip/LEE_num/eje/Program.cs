﻿using System;

namespace Multiplicador
{
    class Numero
    {
        public int Valor { get; set; }

        public int MultiplicarPorDos()
        {
            return Valor * 2;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            // Crear un objeto de tipo Numero
            Numero numero = new Numero();

            // Pedir al usuario que ingrese un número
            Console.Write("Ingrese un número entero: ");
            numero.Valor = Convert.ToInt32(Console.ReadLine());

            // Multiplicar el número por 2 y mostrar el resultado
            int resultado = numero.MultiplicarPorDos();
            Console.WriteLine("El resultado de multiplicar por 2 es: " + resultado);
        }
    }
}