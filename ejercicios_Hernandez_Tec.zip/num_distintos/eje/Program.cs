﻿using System;

class NumeroSerie
{
    public List<int> Numeros { get; set; } = new List<int>();

    public void LeerNumeros()
    {
        Console.WriteLine("Ingrese números. Ingrese 0 para finalizar.");
        int numero;

        do
        {
            numero = Convert.ToInt32(Console.ReadLine());
            if (numero != 0)
            {
                Numeros.Add(numero);
            }
        } while (numero != 0);
    }

    public void ImprimirNumeros()
    {
        Console.WriteLine("Los números ingresados son:");
        foreach (int numero in Numeros)
        {
            Console.WriteLine(numero);
        }
        Console.WriteLine($"Se leyeron {Numeros.Count} números.");
    }
}

class Program
{
    static void Main(string[] args)
    {
        NumeroSerie serie = new NumeroSerie();
        serie.LeerNumeros();
        serie.ImprimirNumeros();
    }
}  